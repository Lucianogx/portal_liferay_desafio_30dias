document.addEventListener("DOMContentLoaded", function () {
    var button = document.getElementById("customButton");
    if (button) {
        button.addEventListener("click", function () {
            alert("Botão clicado!");
        });
    }
});